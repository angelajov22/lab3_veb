package mk.finki.ukim.mk.lab.data;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import mk.finki.ukim.mk.lab.model.Category;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.CategoryRepository;
import mk.finki.ukim.mk.lab.repository.LocationRepository;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializerCategory {

    private final CategoryRepository categoryRepository;

    @PostConstruct
    public void initializeData() {
        for (int i = 0; i < 2; i++) {
            Category category = new Category("Category" + i);
            categoryRepository.save(category);
        }
    }

}