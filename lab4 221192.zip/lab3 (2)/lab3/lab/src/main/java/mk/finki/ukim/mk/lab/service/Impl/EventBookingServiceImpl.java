package mk.finki.ukim.mk.lab.service.Impl;

import lombok.AllArgsConstructor;
import mk.finki.ukim.mk.lab.model.EventBooking;
import mk.finki.ukim.mk.lab.repository.EventBookingRepository;
import mk.finki.ukim.mk.lab.service.EventBookingService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class EventBookingServiceImpl implements EventBookingService {

   final EventBookingRepository eventBookingRepository;

    @Override
    public void placeBooking(String eventName, String attendeeName, String attendeeAddress, int numberOfTickets) {
        EventBooking eventBooking = new EventBooking(eventName,attendeeName,attendeeAddress,(long)numberOfTickets);
        eventBookingRepository.addBookings(eventBooking);
    }

    public List<EventBooking> getAllBookings ()
    {
        return eventBookingRepository.getAllBookings();

    }
}

