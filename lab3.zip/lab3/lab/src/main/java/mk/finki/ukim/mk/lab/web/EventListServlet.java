package mk.finki.ukim.mk.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.finki.ukim.mk.lab.service.EventService;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet(name="event-list-servlet", urlPatterns = "")
public class EventListServlet extends HttpServlet {

    private final EventService eventService;
    private final SpringTemplateEngine springTemplateEngine;

    public EventListServlet(EventService eventService, SpringTemplateEngine springTemplateEngine) {
        this.eventService = eventService;
        this.springTemplateEngine = springTemplateEngine;
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        IWebExchange webExchange = JakartaServletWebApplication
                .buildApplication(getServletContext())
                .buildExchange(req, resp);

        WebContext context = new WebContext(webExchange);

        String searchByName = req.getParameter("name");
        String searchByRating = req.getParameter("rating");

        if(searchByName != null && searchByName.isEmpty()) {
            searchByName = null;
        }

        if(searchByRating != null && searchByRating.isEmpty()) {
            searchByRating = null;
        }

        if (searchByName != null && searchByRating == null) {
            context.setVariable("events", eventService.searchEventsByText(searchByName));
        } else if (searchByName == null && searchByRating != null) {
            context.setVariable("events", eventService.searchEventsByRating(Double.parseDouble(searchByRating)));
        } else if (searchByName != null && searchByRating != null) {
            context.setVariable("events", eventService.searchEventsByTextAndRating(searchByName, Double.valueOf(searchByRating)));
        } else {
            context.setVariable("events", eventService.listAll());
        }

        springTemplateEngine.process("listEvents.html",context, resp.getWriter());

    }
}
